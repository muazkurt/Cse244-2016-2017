//Libraries
	#include <stdio.h>
	#include <stdlib.h>
	#include <string.h>
	#include <errno.h>
	#include <unistd.h>
	#include <fcntl.h>
	#include <sys/stat.h>
	#include <sys/wait.h>
	#include <time.h>
	#include <dirent.h>
	#include <math.h>

int main(int argc, char *argv[])
{
	if(argc != 1)
		fprintf(stderr, "Usage:\n\t%s\n", argv[0]);
}