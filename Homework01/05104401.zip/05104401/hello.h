#ifndef HELLO_H__
#define HELLO_H__

void hello();

#endif
