#include "hello.h"

#include <stdio.h>


void hello(){
	
	printf("Hello System Programming!\n");

}
